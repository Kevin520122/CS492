import 'package:flutter/material.dart';
import 'package:call_me_maybe/app.dart';

void main() {
  runApp(MyApp());
}
